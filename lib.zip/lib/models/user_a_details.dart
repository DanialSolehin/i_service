import 'package:flutter/material.dart';
import 'package:i_service/data/user_a_details.dart';

class UserADetailsScreen extends StatefulWidget {
  final List<UserADetails> userADetails;

  UserADetailsScreen(this.userADetails);

  @override
  _UserADetailsScreenState createState() => _UserADetailsScreenState();
}

class _UserADetailsScreenState extends State<UserADetailsScreen> {
  TextEditingController _nameController = TextEditingController();
  TextEditingController _matricNoController = TextEditingController();
  TextEditingController _contactNoController = TextEditingController();

  bool _isAdding = false;
  bool _isEditing = false;
  int _editIndex = -1;

  List<String> serviceList = [
    'Printing',
    'Posting Stuff',
    'Barber',
    'Personal Shopper',
    'Driver',
  ];

  List<IconData> serviceIcons = [
    Icons.print,
    Icons.post_add,
    Icons.cut,
    Icons.shopping_cart,
    Icons.drive_eta,
  ];

  int _selectedServiceIndex = -1;

  Map<String, Color> serviceColors = {
    'Printing': Colors.blue,
    'Posting Stuff': Colors.green,
    'Barber': Colors.red,
    'Personal Shopper': Colors.orange,
    'Driver': Colors.purple,
  };

Widget _buildServiceIcon(String serviceOffered) {
  Color serviceColor = serviceColors[serviceOffered] ?? const Color.fromARGB(255, 40, 15, 6);

  IconData iconData;
  switch (serviceOffered) {
    case 'Printing':
      iconData = Icons.print;
      break;
    case 'Posting Stuff':
      iconData = Icons.post_add;
      break;
    case 'Barber':
      iconData = Icons.cut;
      break;
    case 'Personal Shopper':
      iconData = Icons.shopping_cart;
      break;
    case 'Driver':
      iconData = Icons.drive_eta;
      break;
    default:
      iconData = Icons.error;
  }

  return CircleAvatar(
    backgroundColor: serviceColor,
    child: Icon(iconData),
  );
}

List<UserADetails> getUserADetails() {
  return widget.userADetails;
}


@override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Student Details'),
        backgroundColor: Colors.brown,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: CircleAvatar(
              backgroundImage: AssetImage('images/download.png'),
              radius: 20,
            ),
          ),
        ], 
      ),
      
      body: Container(
        padding: EdgeInsets.all(20.0),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [const Color.fromARGB(255, 117, 66, 47), Colors.brown],
          ),
        ),
        
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: () {
                setState(() {
                  _isAdding = !_isAdding;
                  if (_isAdding) {
                    _nameController.clear();
                    _matricNoController.clear();
                    _contactNoController.clear();
                    _selectedServiceIndex = -1;
                  }
                });
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.green, 
              ),
              child: Text(_isAdding ? 'Cancel' : 'Add Details'),
            ),
            _isAdding ? _buildAddDetailsForm() : Container(),
            SizedBox(height: 20),
            Expanded(
              child: Card(
                elevation: 4,
                child: _buildUserDetailsList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAddDetailsForm() {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TextFormField(
            controller: _nameController,
            decoration: InputDecoration(labelText: 'Name'),
          ),
          TextFormField(
            controller: _matricNoController,
            decoration: InputDecoration(labelText: 'Matric No'),
          ),
          TextFormField(
            controller: _contactNoController,
            decoration: InputDecoration(labelText: 'Contact No'),
          ),
          SizedBox(height: 2),
          Text('Select Service Offered:'),
          SizedBox(height: 4),
          Wrap(
            spacing: 8.0,
            children: List.generate(
              serviceList.length,
              (index) => ChoiceChip(
                label: Row(
                  children: [
                    Icon(serviceIcons[index]),
                    SizedBox(width: 4),
                    Text(serviceList[index]),
                  ],
                ),
                selected: _selectedServiceIndex == index,
                onSelected: (selected) {
                  setState(() {
                    _selectedServiceIndex = selected ? index : -1;
                  });
                },
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              _addOrUpdateUserDetails();
            },
            child: Text(_isEditing ? 'Update' : 'Add'),
            style: ElevatedButton.styleFrom(
                  primary: const Color.fromARGB(255, 1, 28, 69),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
          ),
          ),
        ],
      ),
    );
  }

Widget _buildUserDetailsList() {
  return Expanded(
    child: ListView.builder(
      itemCount: widget.userADetails.length,
      itemBuilder: (context, index) {
        return ListTile(
          title: Text(widget.userADetails[index].name),
          subtitle: Text(widget.userADetails[index].matricNo + "\n" + widget.userADetails[index].contactNo),

          leading: _buildServiceIcon(widget.userADetails[index].serviceOffered),
          onTap: () {
            _editUserDetails(index);
          },
          trailing: IconButton(
            icon: Icon(Icons.delete),
            onPressed: () {
              _deleteUserDetails(index);
            },
          ),
        );
      },
    ),
  );
}

Widget _buildServicesIcon(String serviceOffered) {
  IconData iconData;
  switch (serviceOffered) {
    case 'Printing':
      iconData = Icons.print;
      break;
    case 'Posting Stuff':
      iconData = Icons.post_add;
      break;
    case 'Barber':
      iconData = Icons.cut;
      break;
    case 'Personal Shopper':
      iconData = Icons.shopping_cart;
      break;
    case 'Driver':
      iconData = Icons.drive_eta;
      break;
    default:
      iconData = Icons.error;
  }
  return Icon(iconData);
}




void _addOrUpdateUserDetails() {
  final String name = _nameController.text;
  final String matricNo = _matricNoController.text;
  final String contactNo = _contactNoController.text;

  if (_isEditing && _editIndex != -1) {
    setState(() {
      widget.userADetails[_editIndex] = UserADetails(
        name: name,
        matricNo: matricNo,
        contactNo: contactNo,
        serviceOffered: _selectedServiceIndex != -1
            ? serviceList[_selectedServiceIndex]
            : '',
        serviceColor: serviceColors[serviceList[_editIndex]] ?? const Color.fromARGB(255, 40, 15, 6),

      );
      _isEditing = false;
      _editIndex = -1;
      _selectedServiceIndex = -1;
    });
  } else {
    setState(() {
      widget.userADetails.add(UserADetails(
        name: name,
        matricNo: matricNo,
        contactNo: contactNo,
        serviceOffered: _selectedServiceIndex != -1
            ? serviceList[_selectedServiceIndex]
            : '',
        serviceColor: serviceColors[serviceList[_selectedServiceIndex]] ?? const Color.fromARGB(255, 40, 15, 6),

      ));
      _nameController.clear();
      _matricNoController.clear();
      _contactNoController.clear();
      _selectedServiceIndex = -1;
    });
  }
}


  void _editUserDetails(int index) {
    setState(() {
      _isEditing = true;
      _editIndex = index;
      _nameController.text = widget.userADetails[index].name;
      _matricNoController.text = widget.userADetails[index].matricNo;
      _contactNoController.text = widget.userADetails[index].contactNo;
      _selectedServiceIndex =
          serviceList.indexOf(widget.userADetails[index].serviceOffered);
    });
  }

  void _deleteUserDetails(int index) {
    setState(() {
      widget.userADetails.removeAt(index);
    });
  }
}